"""Discharge the four queries of the original finite bank using verified Boolean roots."""
from pathlib import Path

def recover(archive,proof_roots,target):
    base=archive.base
    bank=base.read(base.ROOT/'bank.json.xz')
    queried={nd['n'] for nd in bank['nodes'] if nd['t']=='externalActive'}
    if queried!={420,644,806,814} or base.P[-1]!=71:raise ValueError('unexpected archived queries')
    certified={}
    for line in Path(proof_roots).read_text().splitlines():
        p,n,k=map(int,line.split())
        if p==71 and n in queried:certified[n]=max(certified.get(n,0),k)
    if certified.keys()!=queried:raise ValueError('missing finite proof')
    # The pinned checker reads a table ONLY at those four positions. Encode
    # the freshly proved values through its native interface. This artificial
    # point table is never used as an input to the global density recurrence.
    levels=[[] for p in base.P]
    for n,k in certified.items():levels[-1].extend([(n,n+1)]*k)
    values=base.old_profiles(levels,max(queried))
    if any(values[n]!=k for n,k in certified.items()):raise ValueError('incorrect table encoding')
    vals,_,stats=base.check_bank(bank,levels)
    tied=set()
    for i,node in enumerate(bank['nodes']):
        t=node['t']
        if t=='externalActive':tied.add(i);continue
        if t=='small':refs=[]
        elif t in ('pack','qpack'):refs=[row[0] for row in node['rows']]
        elif t=='case':refs=node['cs']
        elif t=='trim':refs=[node['ref']]
        else:raise ValueError('bank rule')
        if any(bank['images'][j][0] in tied for j in refs):tied.add(i)
    if len(tied)!=8 or len(vals)!=4106:raise ValueError('bank size')
    seeds={}
    for i in sorted(tied):
        S,k=vals[i]
        for p in base.P[1:]:
            admissible=[]
            for v in S:
                u=v
                for q in base.P:
                    if q<=max(3,p):
                        while u%q==0:u//=q
                if u==1:admissible.append(v)
            for j,v in enumerate(admissible,1):
                h=k-(len(S)-j)
                if h>0:seeds[p,v]=max(seeds.get((p,v),0),h)
    with target.open('w') as f:
        for (p,n),k in sorted(seeds.items()):print(p,n,k,file=f)
    return {'verified_nodes':stats['nodes'],'queries_with_independent_proofs':[[n,certified[n]] for n in sorted(queried)],
            'restored_nodes':len(tied),'projected_requirements':len(seeds)}

if __name__=='__main__':
    import argparse,sys,json
    ap=argparse.ArgumentParser();ap.add_argument('parent',type=Path);ap.add_argument('archive',type=Path);ap.add_argument('roots',type=Path);ap.add_argument('target',type=Path)
    a=ap.parse_args();sys.path.insert(0,str(a.parent.resolve()))
    from independent_base import prior_module
    print(json.dumps(recover(prior_module(a.archive.resolve()),a.roots,a.target)))
