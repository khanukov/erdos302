// Untrusted search procedure. The separate checker validates the weights it emits.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;

constexpr int capacity = 65536;
struct Row {
    array<int,9> v{};
    int size=0, demand=0, template_id=-1, multiplier=0;
};
vector<int> load_primes(int cap) {
    vector<int> primes;
    for (int i=2;i<=cap;i++) {
        bool ok=true;
        for (int p:primes) {
            if (p*p>i) break;
            if (i%p==0) {ok=false; break;}
        }
        if (ok) primes.push_back(i);
    }
    return primes;
}
int cover(const vector<int>& vertices) {
    vector<int> edges;
    int n=vertices.size();
    for(int i=0;i<n;i++) for(int j=i+1;j<n;j++) for(int k=j+1;k<n;k++)
        if(int64_t(vertices[j])*vertices[k]==int64_t(vertices[i])*(vertices[j]+vertices[k]))
            edges.push_back((1<<i)|(1<<j)|(1<<k));
    vector<int> dp(1<<n);
    for(int m=1;m<(1<<n);m++) for(int e:edges) if((e&m)==e) {
        int best=n;
        for(int i=0;i<n;i++) if(e&(1<<i)) best=min(best,dp[m^(1<<i)]);
        dp[m]=1+best; break;
    }
    return dp.back();
}
int main(int argc,char**argv) {
    if(argc!=6 && argc!=7) return 2;
    int tilt=argc==7?stoi(argv[6]):0;
    if(tilt<0||tilt>5) return 2;
    bool reduce_rows=tilt>=3;tilt%=3;
    int prime=stoi(argv[2]), limit=stoi(argv[3]), rounds=stoi(argv[4]);
    if((prime!=2 && prime<5)||prime>20000||limit<6||limit>16000000||rounds<1||rounds>5000) return 2;
    vector<int> rem(limit+1); iota(rem.begin(),rem.end(),0);
    for(int p:load_primes(prime==2?3:prime)) for(int n=p;n<=limit;n+=p)
        while(rem[n]%p==0) rem[n]/=p;
    vector<Row> rows; vector<int> degree(limit+1);
    auto add=[&](const vector<int>& s,int r,int id,int m) {
        Row row;row.size=int(s.size());row.demand=r;row.template_id=id;row.multiplier=m;
        for(int i=0;i<row.size;i++) {row.v[i]=s[i]*m;degree[row.v[i]]++;}
        rows.push_back(row);
    };
    for(int v=2;v*(v+1)<=limit;v++) for(int u=1;u<v&&v*(u+v)<=limit;u++) {
        if(gcd(u,v)>1||rem[u]!=1||rem[v]!=1||rem[u+v]!=1) continue;
        vector<int> s{u*v,u*(u+v),v*(u+v)};
        for(int m=1;m<=limit/s.back();m++) if(rem[m]==1) add(s,1,-1,m);
    }
    ifstream supports(argv[1]);if(!supports) return 2;
    string line; int id=0;
    while(getline(supports,line)) {
        istringstream input(line);vector<int> s;int a;
        while(input>>a) s.push_back(a);
        if(s.empty()||s.size()>9||!is_sorted(s.begin(),s.end())||s[0]<1) return 2;
        if(s.back()<=limit&&all_of(s.begin(),s.end(),[&](int v){return rem[v]==1;})) {
            int r=cover(s);
            if(r>0) for(int m=1;m<=limit/s.back();m++) if(rem[m]==1) add(s,r,id,m);
        }
        id++;
    }
    size_t count=rows.size();
    vector<int64_t> reward(count);
    for(size_t i=0;i<count;i++) {
        const Row& e=rows[i];int v=e.v[e.size-1];
        int64_t weighted=capacity;
        if(tilt!=0) weighted=min(int64_t(capacity)*(tilt==1?3:4)/2,int64_t(capacity)*limit/v);
        reward[i]=weighted*e.demand;
    }
    vector<int64_t> y(count),u(limit+1),bar(limit+1),load(limit+1);
    // Fixed-point first-order search for a fractional packing.
    // All rounding choices here are irrelevant to soundness.
    for(int t=0;t<rounds;t++) {
        if(reduce_rows && (t==75 || t==180)) {
            size_t kept=0;
            fill(degree.begin(),degree.end(),0);
            for(size_t i=0;i<count;i++) {
                const Row& e=rows[i];int64_t price=0;
                for(int z=0;z<e.size;z++) price+=u[e.v[z]];
                if(y[i]==0 && price>reward[i]+capacity/12) continue;
                for(int z=0;z<e.size;z++) degree[e.v[z]]++;
                rows[kept]=e;reward[kept]=reward[i];y[kept]=y[i];kept++;
            }
            count=kept;rows.resize(count);reward.resize(count);y.resize(count);
        }
        fill(load.begin(),load.end(),0);
        for(size_t i=0;i<count;i++) {
            const Row& e=rows[i]; int64_t residual=reward[i];
            for(int j=0;j<e.size;j++) residual-=bar[e.v[j]];
            y[i]=max<int64_t>(0,y[i]+residual/e.size);
            for(int j=0;j<e.size;j++) load[e.v[j]]+=y[i];
        }
        for(int v=1;v<=limit;v++) if(degree[v]) {
            int64_t next=max<int64_t>(0,u[v]+(load[v]-capacity)/degree[v]);
            bar[v]=2*next-u[v];u[v]=next;
        }
    }
    // Thin weights to an admissible packing, then use unused capacity.
    vector<int> room(limit+1,capacity), weights(count);
    for(size_t i=0;i<count;i++) {
        const Row& e=rows[i];int64_t denom=capacity;
        for(int j=0;j<e.size;j++) denom=max(denom,load[e.v[j]]);
        int w=int(y[i]*capacity/denom);weights[i]=w;
        for(int j=0;j<e.size;j++) room[e.v[j]]-=w;
    }
    for(size_t i=0;i<count;i++) {
        const Row& e=rows[i];int w=capacity;
        for(int j=0;j<e.size;j++) w=min(w,room[e.v[j]]);
        if(w<0) return 2;
        weights[i]+=w;
        for(int j=0;j<e.size;j++) room[e.v[j]]-=w;
    }
    ofstream out(argv[5]);
    if(!out) return 2;
    out<<prime<<' '<<limit<<' '<<capacity<<'\n';
    for(size_t i=0;i<count;i++) if(weights[i]) {
        auto& e=rows[i];out<<weights[i]<<' '<<e.template_id;
        if(e.template_id==-1) for(int j=0;j<3;j++) out<<' '<<e.v[j];
        else out<<' '<<e.multiplier;
        out<<'\n';
    }
    return out?0:2;
}
