"""Exact local cover demands under a partial Boolean assignment."""
from functools import lru_cache

@lru_cache(None)
def edges(shape):
    found=[]
    for j,b in enumerate(shape):
        for k in range(j+1,len(shape)):
            c=shape[k]
            a,rem=divmod(b*c,b+c)
            if rem==0 and a in shape:
                found.append((1<<shape.index(a))|(1<<j)|(1<<k))
    return tuple(found)

@lru_cache(240000)
def conditional(shape,ones,zeros):
    """Return the minimum number of extra vertices. None means impossible."""
    if ones&zeros:
        raise ValueError("inconsistent assignment")
    for edge in edges(shape):
        if edge&ones:
            continue
        candidates=edge&~zeros
        if not candidates:
            return None
        best=None
        while candidates:
            bit=candidates&-candidates
            candidates-=bit
            sub=conditional(shape,ones|bit,zeros)
            if sub is not None and (best is None or sub<best):
                best=sub
        return None if best is None else 1+best
    return 0
