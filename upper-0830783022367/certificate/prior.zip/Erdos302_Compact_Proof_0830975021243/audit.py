"""Independent integration of every cell and vector reconstruction at short horizons."""
import argparse
from collections import defaultdict
from fractions import Fraction
from math import isqrt
from pathlib import Path
import json,sys
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
def cells(path):
    groups=defaultdict(list)
    with Path(path).open() as source:
        for line in source:
            p,a,b,h=map(int,line.split())
            groups[p].append((a,b,h))
    return groups
def validate(base,seeds,new,claimed,limit,P):
    import numpy as np
    byprime=cells(new);old=cells(base)
    extras=defaultdict(list)
    for line in Path(seeds).read_text().splitlines():
        p,t,v=map(int,line.split())
        if t<=limit:extras[p].append((t,v))
    nums=[3,2]+[p for p in range(5,P+1,2) if all(p%q for q in range(3,isqrt(p)+1,2))]
    q0=np.zeros(limit+1,dtype=np.int64);prior=q0.copy()
    x=np.arange(limit+1)
    rho=Fraction(1);tot=Fraction(0);const=0;count=0
    scale=10**24;lo=Fraction(0);hi=Fraction(0)
    for j,p in enumerate(nums):
        idx=x//p
        def reconstruct(group):
            v=np.zeros(limit+2,dtype=np.int64)
            for a,b,h in group:
                if a>limit:break
                v[a]+=h;v[min(limit+1,b)]-=h
            return np.cumsum(v[:-1])
        imp=q0+reconstruct(old[p])
        n=1
        while n<=limit:
            sl=slice(n,min(limit+1,n*p))
            imp[sl]+=imp[idx[sl]];n*=p
        cur=imp.copy()
        for t,v in extras[p]:cur[t]=max(cur[t],v)
        n=1
        while n<=limit:
            sl=slice(n,min(limit+1,n*p))
            cur[sl]=np.maximum(cur[sl],prior[sl]+cur[idx[sl]])
            cur[n]=max(cur[n-1],cur[n]);np.maximum.accumulate(cur[sl],out=cur[sl]);n*=p
        if not np.array_equal(cur-prior-cur[idx],reconstruct(byprime[p])):raise ValueError('profile mismatch '+str(p))
        q0,prior=imp,cur
        group=byprime[p]
        charge=mass=0;parts=[];partial=Fraction(0);in_block=0
        for a,b,h in group:
            if not 0<a<b or h<=0 or a<charge:raise ValueError('invalid cell')
            charge=b
            mass+=scale*h*(b-a)//(a*b)
            partial+=Fraction(h*(b-a),a*b);in_block+=1
            if in_block==256:
                parts.append(partial);partial=Fraction(0);in_block=0
        parts.append(partial)
        while len(parts)>1:
            parts=[sum(parts[i:i+2],Fraction(0)) for i in range(0,len(parts),2)]
        tot+=rho*parts[0]
        lo+=rho*mass/scale;hi+=rho*(mass+len(group))/scale
        const+=(1<<j)*sum(h for a,b,h in group)
        count+=len(group);rho*=Fraction(p-1,p)
    actual=Fraction(*map(int,claimed['exact_upper']))
    if 1-tot!=actual or not 1-hi<=actual<=1-lo:raise ValueError('independent exact density')
    if count!=claimed['cells'] or const!=claimed['finite_constant']:raise ValueError('accounting')
    upper=1-lo
    if -(-upper.numerator*10**12//upper.denominator)!=claimed['headline_numerator_over_1e12']:raise ValueError('outward rounding')
    return {'checked_profile_entries':limit*len(nums),'audited_cells':count,
            'density_bracket_width_less_than':str(Fraction(count,scale)),
            'independent_rounded_coefficient':claimed['headline_numerator_over_1e12'],'finite_constant_matches':True,'exact_density_matches_direct_cell_sum':True}

if __name__=='__main__':
    cli=argparse.ArgumentParser()
    cli.add_argument('work',type=Path)
    cli.add_argument('--base',type=Path)
    cli.add_argument('--limit',type=int,default=100000)
    a=cli.parse_args()
    result=json.loads((a.work/'report.json').read_text())
    profile=a.base or a.work/'parent-run'/(result['variant']+'.cells')
    print(json.dumps(validate(profile,a.work/'merged.seed',a.work/'new.cells',result['inside'],a.limit,5003),indent=2))
