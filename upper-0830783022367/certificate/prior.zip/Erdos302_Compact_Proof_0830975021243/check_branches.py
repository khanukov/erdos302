"""Verify every leaf of each exported binary cover tree using integer arithmetic."""
import json
from pathlib import Path
from branch_common import conditional

CAPACITY=10000000
def require(ok,msg):
    if not ok:
        raise ValueError(msg)

def check(source,support_path,output):
    supports=[tuple(map(int,line.split())) for line in Path(support_path).read_text().splitlines()]
    with Path(source).open() as f:
        proofs=[json.loads(l) for l in f if l.strip()]
    result=[]
    branches=leaves=rows=0
    for p,n,expected,proof in proofs:
        require(p==2 or (p>=5 and all(p%d for d in range(2,int(p**.5)+1))),"prime")
        smooth=[]
        for v in range(1,n+1):
            t=v
            for q in range(2,max(p,3)+1):
                while t%q==0:t//=q
            if t==1:smooth.append(v)
        allowed=set(smooth)
        def rank(row,I,Z):
            key,*payload=row
            if key==-1:
                require(len(payload)==3,"triple encoding")
                a,b,c=payload
                require(0<a<b<c and b*c==a*(b+c),"reciprocal triple")
                vert=tuple(payload)
                require(all(v in allowed for v in vert),"domain")
                return vert,0 if I.intersection(vert) else None if all(v in Z for v in vert) else 1
            require(0<=key<len(supports) and len(payload)==1 and payload[0]>0,"scaled template")
            shape=supports[key]
            vert=tuple(payload[0]*v for v in shape)
            require(all(v in allowed for v in vert),"domain")
            ones=sum(1<<i for i,v in enumerate(vert) if v in I)
            zeros=sum(1<<i for i,v in enumerate(vert) if v in Z)
            return vert,conditional(shape,ones,zeros)
        def visit(node,I,Z):
            nonlocal branches,leaves,rows
            if 'at' in node:
                require(set(node)=={'at','zero','one'},"branch keys")
                v=node['at']
                require(v in allowed and v not in I and v not in Z,"branch variable")
                branches+=1
                left=visit(node['zero'],I,Z|{v});right=visit(node['one'],I|{v},Z)
                return min(left,right)
            leaves+=1
            if 'impossible' in node:
                require(set(node)=={'impossible'} and rank(node['impossible'],I,Z)[1] is None,"false impossibility")
                return n+1
            require(set(node)=={'packing'},"leaf keys")
            load={};weight=0
            for w,*r in node['packing']:
                verts,d=rank(r,I,Z)
                require(isinstance(w,int) and 0<w<=CAPACITY and d is not None,"leaf weight")
                for v in verts:
                    if v not in I and v not in Z:
                        load[v]=load.get(v,0)+w
                        require(load[v]<=CAPACITY,"leaf overload")
                weight+=w*d;rows+=1
            return len(I)+(weight+CAPACITY-1)//CAPACITY
        value=visit(proof,set(),set())
        require(value==expected and 0<=value<=n,"declared lower bound")
        result.append((p,n,value))
    with Path(output).open('w') as f:
        for row in sorted(result):print(*row,file=f)
    return {'prefixes':len(result),'splits':branches,'leaves':leaves,'weighted_rows':rows}
