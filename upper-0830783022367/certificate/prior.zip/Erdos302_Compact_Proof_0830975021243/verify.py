"""End-to-end verifier. Only Python's standard library and C++17 are required."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
ROOT=Path(__file__).resolve().parent
# This path also makes the documented isolated Python invocation work.
sys.path.insert(0,str(ROOT))
from jobs import generate
from check_branches import check as check_tree
from project_branches import project
from outside_ledger import extra
from progression_ledger import tail_mass
from recover_bank import recover
from decimal import Decimal,localcontext
from fractions import Fraction
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
PARENT_SHA='2a33451fd696a5a5dbf9a36440b75ef499952a25c935825e6f4ea68bc7cd1678'
PROGRAMS=['legacy_search','sparse_search','collect','lift','outside_search','outside_check','prime_progressions','kernel_proof','width_proof']
def loadpath(path,name):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def run(args):
    subprocess.run(list(map(str,args)),check=True)
def compile_all(out):
    for name in PROGRAMS:run([os.environ.get('CXX','c++'),'-O3','-std=c++17',ROOT/(name+'.cpp'),'-o',out/name])
def parent_sources(out):
    archive=ROOT/'parent.zip'
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=PARENT_SHA:raise ValueError('wrong parent archive')
    with zipfile.ZipFile(archive) as f:
        for item in f.namelist():
            if Path(item).is_absolute() or '..' in Path(item).parts:raise ValueError('unsafe filename')
        f.extractall(out/'parent-source')
    return out/'parent-source'/'Erdos302_Compact_Proof_0834792034025'
def outside(out,config):
    path=out/'outside.json'
    P,A,L,R=config
    left=[out/'outside_search',P,A,L,R,ROOT/'outside_patterns.txt',180]
    right=[out/'outside_check',P,A,L,R]
    with path.open('w') as dest,subprocess.Popen(list(map(str,left)),stdout=subprocess.PIPE) as producer:
        try:subprocess.run(list(map(str,right)),stdin=producer.stdout,stdout=dest,check=True)
        finally:producer.stdout.close()
        if producer.wait():raise ValueError('outside search exited unsuccessfully')
    return json.loads(path.read_text())
def packings(out,parent,jobs,witness,groups):
    allseeds=[];stats=[];total_bytes=0
    for name,members,X in groups:
        paths=[]
        for g in members:
            exe='legacy_search' if g in ('a','b') else 'sparse_search'
            dictionary=ROOT/'supports.txt' if g in ('d','f') else parent/'supports.txt'
            listed=witness.get(g) if witness else None
            if listed is None:
                files=generate(ROOT/'plans'/(g+'.txt'),out/exe,dictionary,out/'weights'/g,1 if g=='e' else jobs)
            else:
                files=[Path(listed)/('_'.join(line.split())+'.txt') for line in (ROOT/'plans'/(g+'.txt')).read_text().splitlines() if line.strip()]
                if not all(f.is_file() for f in files):raise ValueError('incomplete witness '+g)
            paths+=files
        text=out/(name+'.list');text.write_text(''.join(str(v.resolve())+'\n' for v in sorted(paths)))
        seed=out/(name+'.seed')
        msg=subprocess.check_output(list(map(str,[out/'collect',ROOT/'levels.txt',ROOT/'supports.txt',text,X,seed])),text=True).strip()
        stats.append(msg);allseeds.append(seed);total_bytes+=sum(f.stat().st_size for f in paths)
    return allseeds,stats,total_bytes
def combine(inside,external,progress):
    g,proof=extra(external);tail=Fraction(*map(int,progress['exact_gain']));C=Fraction(*map(int,inside['exact_upper']))-g-tail
    with localcontext() as ctx:
        ctx.prec=62
        value=str(Decimal(C.numerator)/Decimal(C.denominator))
    return {'exact_upper':[str(C.numerator),str(C.denominator)],'decimal_upper':value,
            'headline_numerator_over_1e12':-(-C.numerator*10**12//C.denominator),
            'exact_finite_packing_gain':proof['exact_gain'],'exact_progression_gain':progress['exact_gain'],
            'outside_rows':external['rows'],
            'external_multiplier_count':1+proof['extra_multipliers'],'rough_prime_count':proof['rough_primes']}
def kernel_roots(out,jobs):
    targets=(ROOT/'kernel_targets.txt').read_text().splitlines()
    def evaluate(i):
        lines=targets[i::jobs]
        spec=out/f'kernel-{i}.in';verified=out/f'kernel-{i}.seed';log=out/f'kernel-{i}.log'
        spec.write_text(''.join(line+'\n' for line in lines))
        with log.open('w') as f:
            subprocess.run([str(out/'kernel_proof'),str(spec),'160000',str(verified)],stdout=f,check=True)
        if spec.read_bytes()!=verified.read_bytes():raise ValueError('unverified finite target')
        return [int(line.split()[-1]) for line in log.read_text().splitlines()]
    with ThreadPoolExecutor(jobs) as pool:counts=[v for part in pool.map(evaluate,range(jobs)) for v in part]
    (out/'kernel.seed').write_bytes((ROOT/'kernel_targets.txt').read_bytes())
    return {'proved_prefixes':len(counts),'decision_nodes':sum(counts),'maximum_nodes':max(counts)}

def width_roots(out):
    targets=ROOT/'width_targets.txt';checks=out/'width_input.txt'
    contents=[l.split() for l in targets.read_text().splitlines()]
    checks.write_text(''.join(f'{p} {n}\n' for p,n,k in contents))
    result=out/'width.seed'
    run([out/'width_proof',23,checks,result])
    if result.read_bytes()!=targets.read_bytes():raise ValueError('unverified elimination target')
    return {'exact_prefixes':len(contents),'width_cap':23}

def mainrun(out,variant,jobs,cache=None,basework=None,expect=True):
    out.mkdir(parents=True,exist_ok=True);compile_all(out);parent=parent_sources(out)
    config=json.loads((ROOT/'config.json').read_text())
    if basework is None:
        basework=out/'parent-run'
        run([sys.executable,'-I','-S','-B','-O',parent/'verify.py','--variant',variant,'--jobs',jobs,'--work',basework])
    base=basework/(variant+'.cells')
    if hashlib.sha256(base.read_bytes()).hexdigest()!=config['parent_cells_sha256'][variant]:raise ValueError('parent profile digest')
    allseeds,stats,expanded=packings(out,parent,jobs,cache,config['groups'])
    treeinfo=check_tree(ROOT/'branch_witness.jsonl',ROOT/'supports.txt',out/'branch-roots.seed')
    nr=project(ROOT/'branch_witness.jsonl',ROOT/'supports.txt',out/'branch-proj.seed')
    archived=loadpath(parent/'verify.py','parent_driver').open_archive(out/'recovered')
    bankmod=loadpath(parent/'independent_base.py','parent_bank').prior_module(archived)
    fullbank=recover(bankmod,out/'branch-roots.seed',out/'recovered.seed')
    kern=kernel_roots(out,jobs)
    width=width_roots(out)
    allseeds.extend([out/'branch-roots.seed',out/'branch-proj.seed',out/'recovered.seed',out/'kernel.seed',out/'width.seed'])
    merged=out/'merged.seed'
    with merged.open('wb') as f:
        for s in allseeds:f.write(s.read_bytes())
    run([out/'lift',base,merged,config['base_prime'],config['integration_cutoff'],out/'new.cells'])
    ledger=loadpath(parent/'ledger.py','parent_ledger')
    inside=ledger.calculate(out/'new.cells',config['base_prime'])
    ext=outside(out,config['outside'])
    tailfile=out/'prime-tail.tsv'
    P,A,L,R=config['outside'];last=config['tail_end']
    with tailfile.open('w') as f:subprocess.run([str(out/'prime_progressions'),str(L),str(last)],stdout=f,check=True)
    _,tail=tail_mass(tailfile,P,A,L,last)
    combined=combine(inside,ext,tail)
    report={'variant':variant,'packing_checks':stats,'expanded_inside_weight_bytes':expanded,
            'branch_checks':treeinfo,'recovered_bank':fullbank,'kernel_checks':kern,'width_checks':width,'branch_projected_seeds':nr,'inside':inside,
            'outside':ext,'prime_progressions':tail,'combined':combined,'status':'ACCEPTED'}
    if expect:
        claim=json.loads((ROOT/'claims.json').read_text())[variant]
        if claim!=report:raise ValueError('frozen report mismatch')
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(variant,combined['decimal_upper'],flush=True)
    return report
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--jobs',type=int,default=2)
    parser.add_argument('--work',type=Path)
    parser.add_argument('--variant',choices=['bank','kitamura'],default='bank')
    args=parser.parse_args()
    if not 1<=args.jobs<=32:raise ValueError('job count')
    if args.work:mainrun(args.work.resolve(),args.variant,args.jobs)
    else:
        with tempfile.TemporaryDirectory() as tmp:mainrun(Path(tmp),args.variant,args.jobs)
