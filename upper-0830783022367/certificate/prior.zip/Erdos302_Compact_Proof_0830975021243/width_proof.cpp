// Exact elimination on small smooth-prefix hypergraphs. Oversized tables are skipped.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <tuple>
#include <vector>
using namespace std;
using Edge=array<int,3>;
struct Factor {vector<int> v, table;};
int solve(const vector<Edge>& edges,int width) {
    if(edges.empty()) return 0;
    set<int> vertices;
    for(auto e:edges) for(int v:e) vertices.insert(v);
    vector<int> vs(vertices.begin(),vertices.end());
    map<int,int> ids;for(int i=0;i<int(vs.size());i++) ids[vs[i]]=i;
    vector<set<int>> neighbors(vs.size());vector<Factor> factors;
    for(auto e:edges) {
        vector<int> s{ids[e[0]],ids[e[1]],ids[e[2]]};
        for(int v:s) for(int w:s) if(v!=w) neighbors[v].insert(w);
        vector<int> table(8);table[0]=1;factors.push_back({s,table});
    }
    // Several elimination orders; discard an order as soon as its exact table
    // exceeds the requested width. Choosing an order affects time only.
    vector<int> order;int64_t best_cost=INT64_MAX;
    for(int mode=0;mode<4;mode++){
        auto ns=neighbors;set<int> left;vector<int> candidate;int64_t work=0;
        for(int i=0;i<int(vs.size());i++)left.insert(i);
        while(!left.empty()){
            tuple<int,int,int> best{INT32_MAX,INT32_MAX,INT32_MAX};int a=-1;
            for(int v:left){
                int d=ns[v].size();if(d>width)continue;
                int fill=0;
                if(mode)for(int j:ns[v])for(int k:ns[v])if(j<k&&!ns[j].count(k))fill++;
                tuple<int,int,int> key=mode==0?make_tuple(d,0,v):
                    mode==1?make_tuple(d,fill,v):mode==2?make_tuple(fill,d,-v):make_tuple(d,fill,-v);
                if(key<best){best=key;a=v;}
            }
            if(a<0){work=INT64_MAX;break;}
            work+=int64_t(1)<<(1+ns[a].size());if(work>=best_cost)break;
            for(int v:ns[a]){for(int w:ns[a])if(v!=w)ns[v].insert(w);ns[v].erase(a);}
            candidate.push_back(a);left.erase(a);
        }
        if(candidate.size()==vs.size()&&work<best_cost){order=move(candidate);best_cost=work;}
    }
    if(order.size()!=vs.size()) return -1;
    int constant=0;
    for(int a:order) {
        vector<Factor> keep,used;set<int> other;
        for(auto& f:factors) {
            if(find(f.v.begin(),f.v.end(),a)==f.v.end()) keep.push_back(move(f));
            else {for(int v:f.v) if(v!=a) other.insert(v);used.push_back(move(f));}
        }
        if(int(other.size())>width) throw runtime_error("elimination scope");
        vector<int> joint{a};joint.insert(joint.end(),other.begin(),other.end());
        int states=1<<joint.size();vector<int> sum(states),index(states);
        for(auto& f:used) {
            vector<int> bit(joint.size());
            for(int i=0;i<int(f.v.size());i++) {
                size_t z=find(joint.begin(),joint.end(),f.v[i])-joint.begin();bit.at(z)=1<<i;
            }
            for(int b=0;b<int(bit.size());b++) for(int m=0;m<(1<<b);m++) index[(1<<b)+m]=index[m]|bit[b];
            for(int m=0;m<states;m++) sum[m]+=f.table[index[m]];
        }
        vector<int> result(states/2);
        for(int m=0;m<states/2;m++) result[m]=min(sum[m*2],1+sum[m*2+1]);
        if(other.empty()) constant+=result[0];
        else keep.push_back({vector<int>(other.begin(),other.end()),move(result)});
        factors=move(keep);
    }
    if(!factors.empty()) throw runtime_error("remaining factors");
    return constant;
}
int main(int argc,char**argv) try {
    if(argc!=4) return 2;
    int width=stoi(argv[1]);if(width<0||width>23) return 2;
    ifstream spec(argv[2]);ofstream out(argv[3]);if(!spec||!out) return 2;
    vector<int> largest(500001,1);
    for(int p=2;p<=500000;p++) if(largest[p]==1) for(int m=p;m<=500000;m+=p) largest[m]=p;
    // Equal edge lists have equal minima regardless of isolated vertices.
    map<vector<Edge>,int> cache;
    int p,n;
    while(spec>>p>>n) {
        if(n<1||n>500000||p<2||p>599||largest[p]!=p||p==3) return 2;
        vector<int> v;int last=(p==2?3:p);
        for(int i=1;i<=n;i++) if(largest[i]<=last) v.push_back(i);
        if(v.size()>3000) return 2;
        vector<Edge> edges;
        for(int i=0;i<int(v.size());i++) for(int j=i+1;j<int(v.size());j++) {
            int b=v[i],c=v[j];
            int64_t prod=int64_t(b)*c;
            if(prod%(b+c)==0) {
                int a=int(prod/(b+c));
                if(largest[a]<=last) edges.push_back({a,b,c});
            }
        }
        auto it=cache.find(edges);
        if(it==cache.end()) it=cache.emplace(edges,solve(edges,width)).first;
        if(it->second>=0) out<<p<<' '<<n<<' '<<it->second<<'\n';
    }
    if(!spec.eof()||!out) return 2;
    return 0;
} catch(const exception& e) {cerr<<e.what()<<'\n';return 1;}
