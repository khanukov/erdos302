// A bounded exact decision procedure for short hitting-set certificates.
// Returning "unknown" never creates a lower bound or a certificate.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <tuple>
#include <vector>
using namespace std;
using Edge=vector<int>;using Graph=vector<Edge>;
enum Answer{cover_exists,no_cover,unknown};
struct Decision{
    int n,budget,visited=0;
    bool subset(const Edge& a,const Edge& b){return includes(b.begin(),b.end(),a.begin(),a.end());}
    int kernel(Graph& g,int& k){
        while(!g.empty()){
            vector<char> forced(n+1);bool changed=false;
            for(auto& e:g){
                if(e.empty())return -1;
                if(e.size()==1)forced[e[0]]=1;
            }
            int ones=count(forced.begin(),forced.end(),char(1));
            if(ones){
                k-=ones;if(k<0)return -1;
                g.erase(remove_if(g.begin(),g.end(),[&](const Edge& e){return any_of(e.begin(),e.end(),[&](int a){return forced[a];});}),g.end());
                continue;
            }
            sort(g.begin(),g.end(),[](const Edge& a,const Edge& b){return a.size()==b.size()?a<b:a.size()<b.size();});
            g.erase(unique(g.begin(),g.end()),g.end());
            set<pair<int,int>> binary;
            for(auto& e:g)if(e.size()==2)binary.emplace(e[0],e[1]);
            g.erase(remove_if(g.begin(),g.end(),[&](const Edge& e){
                return e.size()==3 && (binary.count({e[0],e[1]})||binary.count({e[0],e[2]})||binary.count({e[1],e[2]}));}),g.end());
            vector<vector<int>> inc(n+1);
            for(int j=0;j<int(g.size());j++)for(int a:g[j])inc[a].push_back(j);
            // Remove one dominated alternative at a time. Equal incidence
            // classes keep a representative, so simultaneous removals are avoided.
            for(int u=1;u<=n&&!changed;u++)if(!inc[u].empty()){
                for(int v:g[inc[u][0]])if(u!=v&&inc[u].size()<=inc[v].size()&&subset(inc[u],inc[v])){
                    for(int j:inc[u]){
                        auto& e=g[j];e.erase(lower_bound(e.begin(),e.end(),u));
                    }
                    changed=true;break;
                }
            }
            if(!changed)break;
        }
        return g.empty()?1:0;
    }
    bool dual_excludes(const Graph& g,const vector<pair<int,int>>& order,int k){
        // A matching between left and right copies of binary edges has load
        // at most two at each original vertex. Fill any remaining capacity.
        vector<vector<int>> adj(n+1);
        for(const auto& e:g)if(e.size()==2){adj[e[0]].push_back(e[1]);adj[e[1]].push_back(e[0]);}
        vector<int> mate(n+1),seen(n+1),room(n+1,2);int tick=0;
        function<bool(int)> augment=[&](int v){
            for(int u:adj[v])if(seen[u]!=tick){
                seen[u]=tick;if(!mate[u]||augment(mate[u])){mate[u]=v;return true;}
            }
            return false;
        };
        for(int v=1;v<=n;v++)if(!adj[v].empty()){tick++;augment(v);}
        int gain=0;
        for(int u=1;u<=n;u++)if(mate[u]){
            if(find(adj[mate[u]].begin(),adj[mate[u]].end(),u)==adj[mate[u]].end())throw runtime_error("matching edge");
            room[u]--;room[mate[u]]--;gain++;
        }
        if(*min_element(room.begin(),room.end())<0)throw runtime_error("matching overload");
        for(auto [cost,j]:order){
            int w=2;for(int v:g[j])w=min(w,room[v]);
            for(int v:g[j])room[v]-=w;gain+=w;
        }
        if(gain>2*k)return true;
        if(g.size()<26||visited%7!=1)return false;
        const int D=1024;
        vector<int> weight(g.size()),deg(n+1),price(n+1),bar(n+1),load(n+1);
        for(auto& e:g)for(int v:e)deg[v]++;
        for(int it=0;it<55;it++){
            fill(load.begin(),load.end(),0);
            for(int j=0;j<int(g.size());j++){
                int a=D;for(int v:g[j])a-=bar[v];
                weight[j]=clamp(weight[j]+a/int(g[j].size()),0,D);
                for(int v:g[j])load[v]+=weight[j];
            }
            for(int v=1;v<=n;v++)if(deg[v]){
                int val=clamp(price[v]+(load[v]-D)/deg[v],0,2*D);
                bar[v]=2*val-price[v];price[v]=val;
            }
        }
        fill(room.begin(),room.end(),D);gain=0;
        for(int j=0;j<int(g.size());j++){
            int denom=D;for(int v:g[j])denom=max(denom,load[v]);
            int w=weight[j]*D/denom;
            for(int v:g[j])room[v]-=w;gain+=w;
        }
        for(auto [cost,j]:order){
            int w=D;for(int v:g[j])w=min(w,room[v]);
            if(w<0)throw runtime_error("fractional packing overload");
            for(int v:g[j])room[v]-=w;gain+=w;
        }
        return gain>k*D;
    }
    Answer run(Graph g,int k){
        if(k<0)return no_cover;
        if(++visited>budget)return unknown;
        int res=kernel(g,k);if(res!=0)return res>0?cover_exists:no_cover;
        vector<int> degree(n+1);
        for(auto& e:g)for(int v:e)degree[v]+=e.size()==2?3:1;
        // Several integral greedy matchings are independent lower bounds.
        vector<pair<int,int>> order;order.reserve(g.size());
        for(int j=0;j<int(g.size());j++){int cost=0;for(int v:g[j])cost+=degree[v];order.emplace_back(cost,j);}
        sort(order.begin(),order.end());
        for(int pass=0;pass<3;pass++){
            vector<char>used(n+1);int bound=0;
            for(int h=0;h<int(g.size());h++){
                int j=pass==0?order[h].second:pass==1?h:int(g.size())-1-h;
                if(all_of(g[j].begin(),g[j].end(),[&](int v){return !used[v];})){
                    for(int v:g[j])used[v]=1;
                    if(++bound>k)return no_cover;
                }
            }
        }
        if(dual_excludes(g,order,k))return no_cover;
        int v=int(max_element(degree.begin(),degree.end())-degree.begin());
        Graph yes,zero;
        for(auto& e:g){
            auto pos=lower_bound(e.begin(),e.end(),v);
            if(pos==e.end()||*pos!=v){yes.push_back(e);zero.push_back(move(e));}
            else{e.erase(pos);zero.push_back(move(e));}
        }
        auto b=run(move(zero),k);if(b==cover_exists||b==unknown)return b;
        return run(move(yes),k-1);
    }
};
Graph make_graph(int p,int n,int& dimension){
    vector<int> v{1};
    for(int q=2;q<=max(3,p);q++){
        bool prime=true;for(int d=2;d*d<=q;d++)if(q%d==0){prime=false;break;}
        if(!prime)continue;
        size_t existing=v.size();
        for(size_t j=0;j<existing;j++){
            int a=v[j];while(a<=n/q){a*=q;v.push_back(a);}
        }
    }
    sort(v.begin(),v.end());dimension=int(v.size());
    if(dimension>16000)throw runtime_error("large decision domain");
    vector<int> compressed(n+1);
    for(int i=0;i<dimension;i++)compressed[v[i]]=i+1;
    Graph g;
    for(int i=0;i<dimension;i++)for(int j=i+1;j<dimension;j++){
        int b=v[i],c=v[j];int64_t prod=int64_t(b)*c;
        if(prod%(b+c)==0){
            int a=int(prod/(b+c));if(compressed[a])g.push_back({compressed[a],i+1,j+1});
        }
    }
    return g;
}
int main(int argc,char**argv)try{
    if(argc!=4)return 2;
    int cap=stoi(argv[2]);ifstream in(argv[1]);ofstream out(argv[3]);
    if(!in||!out||cap<1||cap>2000000)return 2;
    int p,n,k;while(in>>p>>n>>k){
        if(p<2||p==3||p>599||n<1||n>500000||k<1||k>n)return 2;
        int dim=0;auto g=make_graph(p,n,dim);Decision solver{dim,cap};auto res=solver.run(move(g),k-1);
        if(res==no_cover)out<<p<<' '<<n<<' '<<k<<'\n';
        cout<<p<<' '<<n<<' '<<k<<' '<<(res==no_cover?"proven":res==unknown?"unknown":"cover")<<' '<<solver.visited<<'\n'<<flush;
    }
    return in.eof()&&out?0:2;
}catch(const exception& e){cerr<<e.what()<<'\n';return 1;}
