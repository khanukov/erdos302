"""Independent enumeration of multiplier classes and exact regrouping by threshold."""
from bisect import bisect_right
from fractions import Fraction
import json
from pathlib import Path
from outside_ledger import extra

def independent(raw):
    expected,info=extra(raw)
    A,R,L=raw['lower_band'],raw['kernel'],raw['rough_through']
    upper=max(A,A*((A+1)//4))
    largest=[0]*(max(upper,L)+1)
    for q in range(2,len(largest)):
        if largest[q]==0:
            for t in range(q,len(largest),q):largest[t]=q
    caps=[b for b,u in raw['tiers']];counts=[0]*len(caps);sums=counts[:]
    unit=10**25
    floorcap=[0]*(upper+1);floorcap[1]=caps[-1]
    for t in range(2,upper+1):
        q=largest[t];rem=t//q
        if R<q<=A:
            floorcap[t]=min(floorcap[rem],(q+1)//(2*rem))
            ix=bisect_right(caps,floorcap[t])-1
            if ix>=0:counts[ix]+=1;sums[ix]+=unit//t
    if [[a,n,s] for a,n,s in zip(caps,counts,sums) if n]!=info['tiers']:raise ValueError('multiplier strata')
    taus=[0]*(1+len(caps));rho=unit;k=1
    for upperbound,*values in raw['buckets']:
        for q in range(k+1,upperbound+1):
            if largest[q]==q:rho-=(rho+q-1)//q
        k=upperbound
        for i,v in enumerate(values):taus[i]+=rho*v
    gain=Fraction(taus[0],raw['scale']*unit)
    gain+=sum((Fraction(s*t,raw['scale']*unit*unit) for s,t in zip(sums,taus[1:])),Fraction())
    if gain!=expected:raise ValueError('outside density')
    return {'factorizations_examined':upper,'recovered_extra_multipliers':sum(counts),
            'density_regrouping_matches':True,'rough_endpoint':L}
if __name__=='__main__':
    import sys
    print(json.dumps(independent(json.loads(Path(sys.argv[1]).read_text())),indent=2))
