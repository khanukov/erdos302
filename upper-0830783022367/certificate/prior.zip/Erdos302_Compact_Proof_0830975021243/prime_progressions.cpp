// Exact count of triples of primes in arithmetic progression after the finite packing.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;
using I=int64_t;
const int mod=998244353;
int power(int b,int e){I z=1;for(;e;e>>=1,b=I(b)*b%mod)if(e&1)z=z*b%mod;return z;}
void check(bool b,const char* msg){if(!b)throw runtime_error(msg);}
void transform(vector<int>& a,bool inv){
    int n=a.size();
    for(int i=1,j=0;i<n;i++){int bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j)swap(a[i],a[j]);}
    for(int len=2;len<=n;len*=2){
        int root=power(3,(mod-1)/len);
        if(inv)root=power(root,mod-2);
        for(int i=0;i<n;i+=len){
            I w=1;
            for(int j=0;j<len/2;j++){
                int u=a[i+j],v=int(a[i+j+len/2]*w%mod);
                a[i+j]=u+v<mod?u+v:u+v-mod;a[i+j+len/2]=u-v>=0?u-v:u-v+mod;
                w=w*root%mod;
            }
        }
    }
    if(inv){int scale=power(n,mod-2);for(int& v:a)v=I(v)*scale%mod;}
}
struct Bin{int lo,hi;I rho;};
int main(int argc,char**argv)try{
    check(argc==3,"prime_progressions start-exclusive end-inclusive");
    int base=stoi(argv[1]),last=stoi(argv[2]);check(base>=100&&last>base&&last<=100000000,"range");
    for(int d=2;d*d<=mod;d++)check(mod%d,"NTT modulus");
    for(int factor:{2,7,17})check(power(3,(mod-1)/factor)!=1,"primitive root");
    vector<bool> prime(last+1,true);prime[0]=prime[1]=false;
    for(int p=2;p*p<=last;p++)if(prime[p])for(int m=p*p;m<=last;m+=p)prime[m]=false;
    I rho=1000000000000000000LL;int next=2;vector<Bin> bins;
    for(int lo=base+1;lo<=last;){
        int hi=min(last+1,lo+min(lo/3,3000000));
        for(;next<hi;next++)if(prime[next])rho-=(rho+next-1)/next;
        bins.push_back({lo,hi,rho});lo=hi;
    }
    for(size_t i=0;i<bins.size();i++)for(size_t j=i;j<bins.size()&&bins[j].lo<=3*bins[i].lo;j++){
        auto x=bins[i],y=bins[j];I total=0;
        for(int r:{1,5}){
            int a0=x.lo+(r-x.lo%6+6)%6,b0=y.lo+(r-y.lo%6+6)%6;
            int na=(x.hi+5-a0)/6,nb=(y.hi+5-b0)/6;
            if(na<=0||nb<=0)continue;
            int n=1;while(n<na+nb-1)n*=2;
            check((mod-1)%n==0 && min(na,nb)<mod,"convolution length");
            vector<int>a(n),b(n);
            for(int k=0;k<na;k++)a[k]=prime[a0+6*k];
            for(int k=0;k<nb;k++)b[k]=prime[b0+6*k];
            transform(a,false);
            if(i==j){for(int& v:a)v=I(v)*v%mod;}
            else{transform(b,false);for(int k=0;k<n;k++)a[k]=I(a[k])*b[k]%mod;}
            transform(a,true);
            for(int k=0;k<na+nb-1;k++){
                int midpoint=(a0+b0)/2+3*k;
                if(!prime[midpoint])continue;
                int ways=a[k];
                if(i==j){ways--;check(ways>=0&&ways%2==0,"diagonal");ways/=2;}
                total+=ways;
            }
            // Independently count three individual convolution coefficients.
            for(int k:{(na+nb)/5,(na+nb)/2,3*(na+nb)/4}){
                if(k>=na+nb-1)continue;
                int direct=0;
                for(int u=max(0,k-nb+1);u<min(na,k+1);u++)
                    direct+=int(prime[a0+6*u]&&prime[b0+6*(k-u)]);
                check(a[k]==direct,"convolution spot check");
            }
        }
        cout<<x.lo<<' '<<x.hi<<' '<<y.lo<<' '<<y.hi<<' '<<total<<' '<<y.rho<<'\n';
    }
    return 0;
}catch(const exception& e){cerr<<e.what()<<'\n';return 1;}
