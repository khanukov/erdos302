"""Restrict verified Boolean packing trees to every smaller smooth prefix."""
import json
from pathlib import Path
from branch_common import conditional
from check_branches import CAPACITY

def project(source,support_path,destination):
    shapes=[tuple(map(int,l.split())) for l in Path(support_path).read_text().splitlines()]
    proofs=[json.loads(l) for l in Path(source).read_text().splitlines() if l.strip()]
    maximum=max(record[1] for record in proofs)
    largest=[1]*(maximum+1)
    for p in range(2,maximum+1):
        if largest[p]==1:
            for n in range(p,maximum+1,p):largest[n]=p
    seeds={}
    def leaves(node,I,Z):
        if 'at' not in node:
            if 'packing' in node:yield I,Z,node['packing']
            return
        v=node['at']
        yield from leaves(node['zero'],I,Z|{v})
        yield from leaves(node['one'],I|{v},Z)
    for p,n,_,tree in proofs:
        levels=[2]+[q for q in range(5,p+1,2) if largest[q]==q]
        for q in levels:
            prime=max(3,q)
            profile=[n+1]*(n+1)
            for I,Z,records in leaves(tree,set(),set()):
                if any(largest[v]>prime for v in Z):continue
                earliest=max(Z,default=0)
                inc=[0]*(n+1)
                for v in I:
                    if largest[v]<=prime:inc[v]+=CAPACITY
                for w,key,*payload in records:
                    if key==-1:
                        a,b,c=payload
                        if I.isdisjoint(payload) and all(largest[v]<=prime for v in payload):
                            inc[c]+=w
                        continue
                    s=shapes[key];m=payload[0]
                    if largest[m]>prime:continue
                    vertices=[v*m for v in s]
                    allbits=(1<<len(s))-1
                    on=sum(1<<i for i,v in enumerate(vertices) if v in I)
                    zero=sum(1<<i for i,v in enumerate(vertices) if v in Z)
                    inside=last=0
                    for i,v in enumerate(vertices):
                        if largest[v]>prime:continue
                        inside|=1<<i
                        d=conditional(s,on|(allbits^inside),zero&inside)
                        if d is None:raise ValueError("feasible leaf has an impossible induced row")
                        if d>last:inc[v]+=w*(d-last)
                        if d<last:raise ValueError("conditional rank monotonicity")
                        last=d
                total=0
                for a,delta in enumerate(inc):
                    total+=delta
                    if a>=earliest:profile[a]=min(profile[a],(total+CAPACITY-1)//CAPACITY)
            if max(profile)>n:raise ValueError("tree no admissible leaf")
            best=0
            for a,d in enumerate(profile):
                if d>best:
                    seeds[q,a]=max(seeds.get((q,a),0),d)
                    best=d
    with Path(destination).open('w') as out:
        for (q,a),d in sorted(seeds.items()):print(q,a,d,file=out)
    return len(seeds)
