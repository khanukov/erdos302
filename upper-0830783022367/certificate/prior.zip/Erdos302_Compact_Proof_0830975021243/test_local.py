"""Small independent semantic checks and deliberately altered certificate inputs."""
import argparse
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
import struct
import subprocess
import tempfile

def require(x,m):
    if not x:raise ValueError(m)
def tests(bin_dir,root):
    exe=lambda n:str((bin_dir/n).resolve())
    failures=[]
    def reject(name,args,stdin=None):
        x=subprocess.run(args,input=stdin,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        require(x.returncode!=0,'accepted tampering '+name);failures.append(name)
    with tempfile.TemporaryDirectory() as temp:
        wd=Path(temp);s=wd/'supports';s.write_text('2 3 4 6 12\n')
        lev=wd/'primes';lev.write_text('3\n2\n5\n7\n')
        pack=wd/'pack';files=wd/'list';files.write_text(str(pack)+'\n')
        args=[exe('collect'),str(lev),str(s),str(files),'500000',str(wd/'seeds')]
        for tag,row in [('false edge','1 -1 2 3 7'),('overload','2 -1 2 3 6\n2 -1 2 3 6'),('unknown support','1 3 1')]:
            pack.write_text('7 100 2\n'+row+'\n');reject(tag,args)
        pack.write_text('7 100 2\n2 0 1\n')
        subprocess.run(args,check=True,stdout=subprocess.DEVNULL)
        seed=[tuple(map(int,line.split())) for line in (wd/'seeds').read_text().splitlines()]
        require((2,12,2) in seed,'induced rank on the five-vertex support')
        # Compare the tree-projected bounds to an independent minimum-cover solver.
        smooth_seed=bin_dir/'branch-proj.seed'
        @lru_cache(None)
        def exact(p,n):
            def ok(x):
                for q in range(2,max(3,p)+1):
                    while x%q==0:x//=q
                return x==1
            V=[v for v in range(1,n+1) if ok(v)]
            E=[frozenset(t) for t in combinations(V,3) if t[1]*t[2]==t[0]*(t[1]+t[2])]
            @lru_cache(None)
            def branch(remaining):
                if not remaining:return 0
                edge=E[remaining[0]]
                return 1+min(branch(tuple(j for j in remaining if a not in E[j])) for a in edge)
            return branch(tuple(range(len(E))))
        nsmall=0
        for line in smooth_seed.read_text().splitlines():
            p,n,k=map(int,line.split())
            if n<=50:
                require(k<=exact(p,n),'projected rank');nsmall+=1
        points=[(p,n,z) for p in (2,5,7,13) for n in (22,38,47,56) for z in (exact(p,n),exact(p,n)+1)]
        spec=wd/'kernel-input';spec.write_text(''.join(f'{p} {n} {z}\n' for p,n,z in points))
        actual=wd/'kernel-accepted'
        subprocess.run([exe('kernel_proof'),str(spec),'160000',str(actual)],stdout=subprocess.DEVNULL,check=True)
        accepted={tuple(map(int,l.split())) for l in actual.read_text().splitlines()}
        require(accepted=={(p,n,z) for p,n,z in points if z<=exact(p,n)},'kernel vs direct enumeration')
        start,last=1060,3500
        result=subprocess.check_output([exe('prime_progressions'),str(start),str(last)],text=True)
        prime={x for x in range(start+1,last+1) if all(x%d for d in range(2,int(x**.5)+1))}
        nboxes=0
        for line in result.splitlines():
            l,h,x,y,count,rho=map(int,line.split())
            brute=sum(1 for a in prime if l<=a<h for b in prime if x<=b<y and a<b and (a+b)//2 in prime)
            require(brute==count,'direct prime progression enumeration');nboxes+=1
        data=subprocess.check_output([exe('outside_search'),'67','67','521','7',str(root/'outside_patterns.txt'),'180'])
        outside=[exe('outside_check'),'67','67','521','7']
        require(len(data)>32 and len(data)%16==0,'small outside stream')
        subprocess.run(outside,input=data,stdout=subprocess.DEVNULL,check=True)
        row=data[:16];p,q,r,v=struct.unpack('=4I',row)
        reject('repeated outside vertex',outside,row+row)
        reject('invalid outside prime',outside,struct.pack('=4I',p,q,68,v))
        reject('repeated outside atom',outside,struct.pack('=4I',p,q,p,v))
        reject('false denominator equation',outside,struct.pack('=4I',p,q,r,v^(3<<16)))
        reject('truncated binary witness',outside,row[:-1])
        reject('wrong smooth label',outside,struct.pack('=4I',p,q,r,v|255))
        import check_branches as cb
        proofs=[json.loads(s) for s in (root/'branch_witness.jsonl').read_text().splitlines()]
        tree=next(r for r in proofs if 'at' in r[-1])
        from copy import deepcopy
        for name in ('incorrect branch value','inconsistent variable','overweight leaf'):
            raw=deepcopy(tree)
            if name=='incorrect branch value':raw[2]+=1
            elif name=='inconsistent variable':raw[3]['at']=0
            else:
                node=raw[-1]
                while 'at' in node:node=node['one']
                node['packing'][0][0]=cb.CAPACITY+1
            f=wd/'bad.jsonl';f.write_text(json.dumps(raw)+'\n')
            try:cb.check(f,root/'supports.txt',wd/'none')
            except ValueError:failures.append(name)
            else:raise ValueError('accepted '+name)
    return {'brute_force_tree_prefixes':nsmall,'kernel_decisions_vs_brute_force':len(points),'directly_counted_small_prime_boxes':nboxes,'rejected_inputs':failures}
if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('work',type=Path)
    print(json.dumps(tests(cli.parse_args().work,Path(__file__).resolve().parent),indent=2))
