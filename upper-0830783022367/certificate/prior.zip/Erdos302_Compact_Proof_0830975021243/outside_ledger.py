"""Downward rational rounding for every auxiliary density in the outside proof."""
from collections import Counter
from fractions import Fraction
from math import isqrt
from bisect import bisect_right

def primes(limit):
    flags=bytearray(b'\x01')*(limit+1)
    flags[0:2]=b'\x00\x00'
    for d in range(2,isqrt(limit)+1):
        if flags[d]:
            flags[d*d::d]=bytes((limit-d*d)//d+1)
    return [i for i,v in enumerate(flags) if v]

def extra(data):
    L,A,R=data['rough_through'],data['lower_band'],data['kernel']
    allprimes=primes(L)
    scale=10**25
    rho=scale
    for p in allprimes:
        rho=rho*(p-1)//p
    allowed=[p for p in allprimes if R<p<=A]
    caps,units=zip(*data['tiers'])
    masses=Counter()
    counts=Counter()
    def expand(product,start,old_cap):
        for i in range(start,len(allowed)):
            p=allowed[i]
            cap=min(old_cap,(p+1)//(2*product))
            if cap<caps[0]:
                continue
            t=product*p
            j=bisect_right(caps,cap)-1
            masses[j]+=scale//t
            counts[j]+=1
            if 2*t*caps[0]<=A+1:
                expand(t,i,cap)
    expand(1,0,caps[-1])
    unit=data['scale']
    mass=Fraction(data['units'],unit)
    mass+=sum((Fraction(masses[j]*units[j],scale*unit) for j in masses),Fraction())
    if 'buckets' in data:
        gain=Fraction(0)
        prod=scale;ix=0
        for end,scalar,*scaled in data['buckets']:
            while ix<len(allprimes) and allprimes[ix]<=end:
                p=allprimes[ix];prod=prod*(p-1)//p;ix+=1
            this=Fraction(scalar,unit)
            this+=sum((Fraction(masses[j]*scaled[j],scale*unit) for j in masses),Fraction())
            gain+=Fraction(prod,scale)*this
    else:
        gain=Fraction(rho,scale)*mass
    return gain,{'scale':scale,'rough_density_units':rho,'rough_primes':len(allprimes),
                 'extra_multipliers':sum(counts.values()),'tiers':[[caps[j],counts[j],masses[j]] for j in sorted(masses)],
                 'exact_gain':[str(gain.numerator),str(gain.denominator)]}

if __name__=='__main__':
    import json,sys
    from decimal import Decimal
    for f in sys.argv[1:]:
        d=json.load(open(f))
        g,info=extra(d)
        print(f,d['rows'],info['extra_multipliers'],Decimal(g.numerator)/Decimal(g.denominator))
