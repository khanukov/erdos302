// Integer heuristic producing witnesses. collect.cpp independently checks every row.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
constexpr int D = 65536;
void require(bool v,const char* msg){if(!v)throw runtime_error(msg);}
struct Row {int offset, template_id; short size, demand;};
int minimum_cover(const vector<int>& vertex) {
    using Mask=uint64_t; vector<Mask> edges;
    int k=vertex.size();
    for(int i=0;i<k;i++)for(int j=i+1;j<k;j++)for(int h=j+1;h<k;h++)
        if(int64_t(vertex[i])*(vertex[j]+vertex[h])==int64_t(vertex[j])*vertex[h])
            edges.push_back((Mask(1)<<i)|(Mask(1)<<j)|(Mask(1)<<h));
    map<Mask,int> memo;
    auto solve=[&](auto&& self,Mask mask)->int{
        auto known=memo.find(mask);if(known!=memo.end())return known->second;
        for(Mask e:edges)if((mask&e)==e){
            int best=k;
            for(Mask bits=e;bits;bits&=bits-1)best=min(best,self(self,mask^(bits&-bits)));
            return memo[mask]=1+best;
        }
        return 0;
    };
    return solve(solve,(Mask(1)<<k)-1);
}
int main(int argc,char**argv)try {
    require(argc==7,"sparse_search supports prime limit rounds output style");
    int P=stoi(argv[2]),N=stoi(argv[3]),rounds=stoi(argv[4]),style=stoi(argv[6]);
    require(P>=5&&P<=20000&&N>=6&&N<=96000000&&rounds>0&&rounds<=10000&&style>=0&&style<=2,"parameter");
    vector<int> index(N+1,-1),value,primes;
    index[1]=0;
    for(int p=2;p<=P;p++){
        bool good=true;for(int q:primes){if(q*q>p)break;if(p%q==0){good=false;break;}}
        if(!good)continue;
        primes.push_back(p);
        for(int m=1;m<=N/p;m++)if(index[m]>=0)index[m*p]=0;
    }
    for(int t=1;t<=N;t++)if(index[t]>=0){index[t]=int(value.size());value.push_back(t);}
    vector<int> degree(value.size()),vertices,template_first;
    vector<Row> rows;
    auto add_family=[&](const vector<int>& shape,int demand,int id){
        for(int m:value){
            if(m>N/shape.back())break;
            rows.push_back({int(vertices.size()),id,short(shape.size()),short(demand)});
            for(int t:shape){int v=index[m*t];vertices.push_back(v);degree[v]++;}
        }
    };
    for(int v=2;v*(v+1)<=N;v++)if(index[v]>=0)for(int u=1;u<v&&v*(u+v)<=N;u++){
        if(index[u]<0||index[u+v]<0||gcd(u,v)!=1)continue;
        add_family({u*v,u*(u+v),v*(u+v)},1,-1);
    }
    ifstream file(argv[1]);require(bool(file),"supports");
    string line;
    while(getline(file,line)){
        istringstream s(line);vector<int> shape;int v;while(s>>v)shape.push_back(v);
        require(shape.size()>=3 && shape.size()<=40 && shape[0]>0 && is_sorted(shape.begin(),shape.end()),"support");
        int id=template_first.size();template_first.push_back(shape[0]);
        if(shape.back()>N||any_of(shape.begin(),shape.end(),[&](int a){return index[a]<0;}))continue;
        int demand=minimum_cover(shape);if(demand)add_family(shape,demand,id);
    }
    vector<int>().swap(index);
    vector<int> weight(rows.size()),price(value.size()),extrap(value.size()),active;
    vector<int64_t> load(value.size());
    auto filter_vertices=[&](){active.clear();for(int i=0;i<int(value.size());i++)if(degree[i])active.push_back(i);};
    filter_vertices();
    auto reward=[&](const Row& row) {
        if(!style)return D*int(row.demand);
        int top=value[vertices[row.offset+row.size-1]];
        int per=int(min<int64_t>(D*(style==1?3:4)/2,int64_t(D)*N/top));
        return per*row.demand;
    };
    for(int iter=0;iter<rounds;iter++){
        if(iter==50||iter==140){
            size_t keep=0;int position=0;
            fill(degree.begin(),degree.end(),0);
            for(size_t i=0;i<rows.size();i++){
                auto row=rows[i];int total=0;
                for(int j=0;j<row.size;j++)total+=price[vertices[row.offset+j]];
                if(weight[i]==0&&total>reward(row)+D/12)continue;
                int pos=row.offset;row.offset=position;
                for(int j=0;j<row.size;j++){int v=vertices[pos+j];vertices[position++]=v;degree[v]++;}
                rows[keep]=row;weight[keep++]=weight[i];
            }
            rows.resize(keep);weight.resize(keep);vertices.resize(position);filter_vertices();
        }
        for(int v:active)load[v]=0;
        for(size_t i=0;i<rows.size();i++){
            auto& r=rows[i];int residual=reward(r);auto vs=vertices.data()+r.offset;
            for(int j=0;j<r.size;j++)residual-=extrap[vs[j]];
            int w=clamp(weight[i]+residual/r.size,0,D);weight[i]=w;
            for(int j=0;j<r.size;j++)load[vs[j]]+=w;
        }
        for(int v:active){
            int next=clamp<int64_t>(price[v]+(load[v]-D)/degree[v],0,D*3);
            extrap[v]=2*next-price[v];price[v]=next;
        }
    }
    vector<int> room(value.size(),D);
    for(size_t i=0;i<rows.size();i++){
        auto& r=rows[i];auto vs=vertices.data()+r.offset;int64_t scale=D;
        for(int j=0;j<r.size;j++)scale=max(scale,load[vs[j]]);
        weight[i]=int(int64_t(weight[i])*D/scale);
        for(int j=0;j<r.size;j++)room[vs[j]]-=weight[i];
    }
    ofstream out(argv[5]);require(bool(out),"output");out<<P<<' '<<N<<' '<<D<<'\n';
    for(size_t i=0;i<rows.size();i++){
        auto& r=rows[i];auto vs=vertices.data()+r.offset;int spare=D;
        for(int j=0;j<r.size;j++)spare=min(spare,room[vs[j]]);
        require(spare>=0,"overload");
        for(int j=0;j<r.size;j++)room[vs[j]]-=spare;
        int w=weight[i]+spare;if(!w)continue;
        out<<w<<' '<<r.template_id;
        if(r.template_id<0)for(int j=0;j<3;j++)out<<' '<<value[vs[j]];
        else out<<' '<<value[vs[0]]/template_first[r.template_id];
        out<<'\n';
    }
    require(bool(out),"write failed");return 0;
}catch(const exception& e){cerr<<e.what()<<'\n';return 1;}
