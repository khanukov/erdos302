"""Disjoint prime ranges, exact AP counts and conservative rational endpoint masses."""
from fractions import Fraction
from math import isqrt,gcd

def tail_mass(path,base_prime,atom_start,finite_end,stop):
    T=4800
    H=28*T
    inc=[H+1]*(2*T+1)
    for v in range(2,isqrt(H)+1):
        for u in range(1,v):
            a,b,c=u*v,u*(u+v),v*(u+v)
            if c>H:break
            if gcd(u,v)!=1:continue
            for m in range(1,min(2*T//a,H//c)+1):
                for s in (m*a,m*b,m*c):
                    if s<=2*T:inc[s]=min(inc[s],m*c)
    # Only small odd multipliers are used, so odd/even roles stay separate.
    usable=bytearray([1])*(T+1)
    for q in range(atom_start+1,T+1):
        if all(q%k for k in range(2,isqrt(q)+1)):
            usable[q::q]=bytes(T//q)
    ts=[t for t in range(1,T+1,2) if usable[t] and inc[2*t]>2*t]
    unit=10**32
    numerator=0;pairs=0;count=0
    bins=[];l=finite_end+1
    while l<=stop:
        end=min(stop+1,l+min(l//3,3000000));bins.append((l,end));l=end
    expected={(a,b,c,d) for i,(a,b) in enumerate(bins) for c,d in bins[i:] if c<=3*a}
    checked=set()
    for line in open(path):
        lo,hi,x,y,tot,rho=map(int,line.split());key=lo,hi,x,y
        if key not in expected or key in checked or tot<0 or not 0<rho<=10**18:raise ValueError('AP bins')
        checked.add(key);count+=tot;pairs+=1
        # q=(p+v)/2. The quantities hi and y are conservative upper bounds.
        base_low=y*(hi+y)
        gain=0
        for t in ts:
            twice_high=min(2*lo*x*inc[t],lo*(lo+x)*inc[2*t])
            if twice_high>2*t*base_low:
                lower=unit//(t*base_low)-(2*unit+twice_high-1)//twice_high
                gain+=max(0,lower)
        numerator+=tot*rho*gain
    if checked!=expected or atom_start>base_prime:raise ValueError('incomplete AP count')
    g=Fraction(numerator,2*10**18*unit)
    return g,{'boxes':pairs,'prime_progressions':count,'multiplier_candidates':len(ts),
              'exact_gain':[str(g.numerator),str(g.denominator)],'last_prime_candidate':stop}
