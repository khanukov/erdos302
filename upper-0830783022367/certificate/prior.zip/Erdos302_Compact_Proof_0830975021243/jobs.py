"""Regenerate integer witnesses. Each solver output is checked in a separate stage."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import subprocess
import time

def generate(schedule, binary, supports, directory, workers, cached=False):
    directory=Path(directory)
    directory.mkdir(parents=True,exist_ok=True)
    rows=[tuple(map(int,l.split())) for l in Path(schedule).read_text().splitlines() if l.strip()]
    if any(len(r)!=4 for r in rows) or len(set(rows))!=len(rows):
        raise ValueError("invalid job schedule")
    def run(row):
        p,n,rounds,style=row
        name='_'.join(map(str,row))
        out=directory/(name+'.txt')
        start=time.monotonic()
        if not cached or not out.is_file():
            partial=directory/(name+'.partial')
            subprocess.run([str(binary),str(supports),str(p),str(n),str(rounds),str(partial),str(style)],check=True)
            partial.replace(out)
        print(name,out.stat().st_size,round(time.monotonic()-start,2),flush=True)
        return out
    with ThreadPoolExecutor(max_workers=workers) as pool:
        files=[f.result() for f in as_completed([pool.submit(run,row) for row in rows])]
    return sorted(files)

if __name__=='__main__':
    import sys
    generate(*map(Path,sys.argv[1:5]),int(sys.argv[5]),cached=True)
